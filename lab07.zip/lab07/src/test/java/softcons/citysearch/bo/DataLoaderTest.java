/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package softcons.citysearch.bo;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import softcons.citysearch.model.City;

/**
 *
 * @author aamnasayyed
 */
public class DataLoaderTest {
    
    public DataLoaderTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of LoadData method, of class DataLoader.
     */
    @Test
    public void testLoadData() {
        System.out.println("LoadData");
        DataLoader instance = new DataLoader();
        instance.LoadData();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loadFromCSV method, of class DataLoader.
     *

    /**
     * Test of SearchCity method, of class DataLoader.
     */
    @Test
    public void testSearchCity() {
        System.out.println("SearchCity");
        DataLoader instance = new DataLoader();
        String city=instance.SearchCity();
        assertEquals("Cape Town",city);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

   
    @Test
    public void testDistance() {
        System.out.println("distance");
        String unit = "";
        DataLoader instance = new DataLoader();
        double expResult = 120.0;
        double result = instance.distance("K");
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
