package softcons.citysearch.model;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aamnasayyed
 */
@Entity
@Table(name = "passwords")

public class Passwords {
    
    private String userid;
    private String scheme;
    private float time;
    private boolean state;
     private float challenge01;
     private boolean statec1;
     private float challenge02;
     private boolean statec2;
     private float challenge03;
     private boolean statec3;
     private float challenge04;
     private boolean statec4;
     private float challenge05;
     private boolean statec5;
     private float challenge06;
   private boolean statec6;
     private float challenge07;
     private boolean statec7;
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public float getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public boolean isState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public float getChallenge01() {
        return challenge01;
    }

    public void setChallenge01(float challenge01) {
        this.challenge01 = challenge01;
    }

    public boolean isStatec1() {
        return statec1;
    }

    public void setStatec1(boolean statec1) {
        this.statec1 = statec1;
    }

    public float getChallenge02() {
        return challenge02;
    }

    public void setChallenge02(float challenge02) {
        this.challenge02 = challenge02;
    }

    public boolean isStatec2() {
        return statec2;
    }

    public void setStatec2(boolean statec2) {
        this.statec2 = statec2;
    }

    public float getChallenge03() {
        return challenge03;
    }

    public void setChallenge03(float challenge03) {
        this.challenge03 = challenge03;
    }

    public boolean isStatec3() {
        return statec3;
    }

    public void setStatec3(boolean statec3) {
        this.statec3 = statec3;
    }

    public float getChallenge04() {
        return challenge04;
    }

    public void setChallenge04(float challenge04) {
        this.challenge04 = challenge04;
    }

    public boolean isStatec4() {
        return statec4;
    }

    public void setStatec4(boolean statec4) {
        this.statec4 = statec4;
    }

    public float getChallenge05() {
        return challenge05;
    }

    public void setChallenge05(float challenge05) {
        this.challenge05 = challenge05;
    }

    public boolean isStatec5() {
        return statec5;
    }

    public void setStatec5(boolean statec5) {
        this.statec5 = statec5;
    }

    public float getChallenge06() {
        return challenge06;
    }

    public void setChallenge06(float challenge06) {
        this.challenge06 = challenge06;
    }

    public boolean isStatec6() {
        return statec6;
    }

    public void setStatec6(boolean statec6) {
        this.statec6 = statec6;
    }

    public float getChallenge07() {
        return challenge07;
    }

    public void setChallenge07(float challenge07) {
        this.challenge07 = challenge07;
    }

    public boolean isStatec7() {
        return statec7;
    }

    public void setStatec7(boolean statec7) {
        this.statec7 = statec7;
    }
  
     
     
     
     
     
    
    
    
    
    
}
