
package softcons.citysearch.bo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.Transaction;
import softcons.citysearch.model.Passwords;
import softcons.citysearch.util.HibernateUtil;
import java.util.Scanner;
import org.hibernate.Query;
import java.util.List;
import java.util.*;
import java.lang.*;
import java.io.*;
import static java.lang.Math.toRadians;
/**
 *
 * @author aamnasayyed
 */
public class DataLoader {
    
    public Session session;  
    public String csvFileLocation;
    public ArrayList<Passwords> passwordData = new ArrayList<>();
    public List<Passwords> l1;
    public DataLoader(){
        csvFileLocation = "C:\\Users\\aamna sayyed\\Documents\\NetBeansProjects\\citysearch\\target\\classes\\test_two_anon.csv";
    }
    

    public void LoadData(){
        session=HibernateUtil.getSessionFactory().openSession();
        
        ArrayList<Passwords> pass = loadFromCSV();
        
        Transaction loadTransaction = session.beginTransaction();
        for(int passIte = 0; passIte< pass.size(); passIte++){
            session.persist(pass.get(passIte));//persisting the object  
        }
        loadTransaction.commit();
        session.close();
        
    }
    
    public ArrayList<Passwords> loadFromCSV(){
        
        BufferedReader br = null;
        String CSVline = "";
        String delimiter = ",";
        
        
        try {

            br = new BufferedReader(new FileReader(csvFileLocation));
            while ((CSVline = br.readLine()) != null) {

                String[] csvStringData = CSVline.split(delimiter);
                //locId,country,region,city,postalCode,latitude,longitude,metroCode,areaCode
                Passwords temp= new Passwords();
                if(csvStringData.length>6){
                    
                    temp.setUserid(csvStringData[1]);
                    temp.setScheme(csvStringData[3]);
                    temp.setState(true);
                    temp.setChallenge01(5);
                     temp.setChallenge02(7);
                      temp.setChallenge03(9);
                       temp.setChallenge04(11);
                        
                    temp.setStatec1(true);
                     temp.setStatec2(true);
                      temp.setStatec3(true);
                       temp.setStatec4(true);
                       temp.setStatec5(true);
                        temp.setStatec6(true);
//                    if(Double.isNaN(Double.parseDouble(csvStringData[5])) || Double.isNaN(Double.parseDouble(csvStringData[6]))){
//                        continue;
//                    }
                    
                }
                System.out.println(temp);
                passwordData.add(temp);

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
   return passwordData;
    }
    



  public void searchtimetaken()
    {
        
        
        session=HibernateUtil.getSessionFactory().openSession();
        Scanner sc=new Scanner(System.in);
        String input=sc.next();
        String hql = "SELECT * FROM passwords P where userid='"+input+"'";
Query query = session.createQuery(hql);
List l1 = query.list();
       
       
        System.out.println(l1);
    }
    
    
    public void printdata()
    {
        
    for(Passwords mydata: passwordData) {
    System.out.println(mydata);  // Will invoke overrided `toString()` method
}
    }


}