/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant.reservation.system;
import java.io.*;
import java.util.*;
import java.util.Scanner;
import java.util.List;
import java.util.Date;
import java.util.Calendar;

public class RestaurantReservationSystem {

   Table head;
  Table tab;
 
  Boolean has_restaurant_opened()
  {
      boolean isopen;
     Calendar calendar= Calendar.getInstance();
     int hour=calendar.get(Calendar.HOUR_OF_DAY);
     if(hour>22|| hour<11)
     {
         System.out.print("restaurant is closed\n");
         isopen=false;
        
     }
     else
         
     {
         System.out.print("restaurant is open. You can make a reservation\n");
         isopen=true;
     }
     

return isopen;
  }
void insertTable(int tableid,String size)
    {
        Table current_table= new Table();
        if(head==null)
        {
            head=current_table;
        }
        else
        {
            Table temp=head;
            
            while(temp.getnexttable()!=null)
            {
                temp=temp.getnexttable();
                
            }
            temp.setnextable(current_table);
        }
    }
     void search_and_reserve_table(String description)
     {
         Table temp_table=new Table();
         temp_table=head;
         if(temp_table==null)
             System.out.print("No service available, sorry for inconvinience\n");
         else
         {
             String x=temp_table.getsize();
             while(x!=description)
             {
                 temp_table=temp_table.getnexttable();
             }
             if(temp_table.get_availability()==false)
                 System.out.print("Sorry, no free table at the moment\n");
             else
             {
                
                
                temp_table.set_availability(false);
                 Calendar tabletime= Calendar.getInstance();
     int hour=tabletime.get(Calendar.HOUR_OF_DAY);
     hour=hour+1;
                temp_table.set_table_time(hour);
                 System.out.print("Your Table is available and has been booked\n");
                //display_menu();
             }
         }
         
     }
      void remove_table(Table table)
      {
          table.tableid=table.getnexttable().tableid;
          table.availability=table.getnexttable().get_availability();
          table.table_time=table.getnexttable().get_table_time();
          table.size=table.getnexttable().getsize();
          table.nexttable=table.getnexttable().getnexttable();
      }
     
     void display_menu()
     {
      String[]apetizer={"Chicken Dips","CheeseBalls","JalepenoPoppers","BLT Bites"};
       String[]soups={"Corn soup","Creame Soup"};
        String[]coursedishes={"Biryani","Pizza","Qorma","Karahi","WhiteKarahi","Chowmein","Fish qorma"};
         String[]sidedishes={"Chicken Burger","Fajita Pizza"};
          String[]desserts={"Molten Lava","Tirramissu","Cookies","Brownies"};
          
        System.out.println(apetizer);
         System.out.println(soups);
          System.out.println(coursedishes);
           System.out.println(sidedishes);
            System.out.println(desserts);
     }
     
     void print()
     {
         Table table=new Table();
         if(head==null)
         {
            System.out.println("no tables");
         }
         else
         {
             table=head;
             while(table.getnexttable()!=null)
             {
                 System.out.println(table.get_availability());
                  System.out.println(table.get_table_time());
                   System.out.println(" ");
                   table=table.getnexttable();
             }
         }
     }

    public static void main(String[] args) {
        // TODO code application logic here
        
        // TODO code application logic here
                 RestaurantReservationSystem rs=new RestaurantReservationSystem();
        int count=1;
         rs.insertTable(count,"ExtraLarge");
        
         for(int i=1;i<4;i++)
         {
            ++count;
         rs.insertTable(count,"Large");
         
         }
          for(int i=1;i<9;i++)
         {
           ++count;
         rs.insertTable(count,"Large");
        
         }
          rs.print();
Boolean open=rs.has_restaurant_opened();
         if(open.equals(true))
         {
           rs.search_and_reserve_table("Large");
         };

    }
    
}
class Table
{
    int tableid;
    String size;
    Boolean availability;
    Table nexttable;
    int table_time;
    
    Table()
    {
       
    availability=true;
  
    }
    public boolean checkavailability(Table t)
    {
        if(t.availability==true)
            return true;
        else
            return false;
    }
   void set_availability(boolean x)
   {
       availability=x;
   }
   boolean get_availability()
   {
       return availability;
   }
    void settableid(int tid)
    {
        tableid=tid;
    }
    int gettableid()
    {
        return tableid;
     }
    
     void setsize(String sz)
    {
        size=sz;
    }
    String getsize()
    {
        return size;
     }
    
     void setnextable(Table table)
    {
        nexttable=table;
    }
    Table getnexttable()
    {
        return nexttable;
     }
    void set_table_time(int x)
    {
        table_time=x;
    }
    int get_table_time()
    {
     return table_time;   
    }
   
 }




