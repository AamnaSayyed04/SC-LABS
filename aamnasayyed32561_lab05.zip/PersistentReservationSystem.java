/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistent.reservation.system;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class PersistentReservationSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try
        {
 String host="jdbc:derby://localhost:1527/restaurant_reservation";
 String uName="root";
 String uPass="root";
 
 Connection conn=DriverManager.getConnection(host,uName,uPass);
    }
        catch(SQLException err)
        {
            System.out.println(err.getMessage());
        }
    }
    
}
 class authentication
{
     //Class.forName("com.mysql.jdbc.Driver");
     
    
}



