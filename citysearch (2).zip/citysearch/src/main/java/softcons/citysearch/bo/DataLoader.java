
package softcons.citysearch.bo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.Transaction;
import softcons.citysearch.model.City;
import softcons.citysearch.util.HibernateUtil;
import java.util.Scanner;
import org.hibernate.Query;
import java.util.List;
/**
 *
 * @author aamnasayyed
 */
public class DataLoader {
    
    public Session session;  
    public String csvFileLocation;
    public ArrayList<City> cityData = new ArrayList<>();
    public List<City> l1;
    public DataLoader(){
        csvFileLocation = "C:\\Users\\aamna sayyed\\Documents\\NetBeansProjects\\citysearch\\target\\classes\\GeoLiteCity-Location.csv";
    }
    

    public void LoadData(){
        session=HibernateUtil.getSessionFactory().openSession();
        
        ArrayList<City> cities = loadFromCSV();
        
        Transaction loadTransaction = session.beginTransaction();
        for(int cityIte = 0; cityIte< cities.size(); cityIte++){
            session.persist(cities.get(cityIte));//persisting the object  
        }
        loadTransaction.commit();
        session.close();
        
    }
    
    public ArrayList<City> loadFromCSV(){
        
        BufferedReader br = null;
        String CSVline = "";
        String delimiter = ",";
        
        
        try {

            br = new BufferedReader(new FileReader(csvFileLocation));
            while ((CSVline = br.readLine()) != null) {

                String[] csvStringData = CSVline.split(delimiter);
                //locId,country,region,city,postalCode,latitude,longitude,metroCode,areaCode
                City tempCity = new City();
                if(csvStringData.length>6){
                    
                    tempCity.setCountry(csvStringData[1]);
                    tempCity.setCity(csvStringData[3]);
//                    if(Double.isNaN(Double.parseDouble(csvStringData[5])) || Double.isNaN(Double.parseDouble(csvStringData[6]))){
//                        continue;
//                    }
                    try{
                    tempCity.setLatitude(Double.parseDouble(csvStringData[5]));
                    tempCity.setLongitude(Double.parseDouble(csvStringData[6]));
                    }catch(NumberFormatException nfe){
                        System.out.println("line does not have a lat/long:"+CSVline);
                        continue;
                    }
                }
                System.out.println(tempCity);
                cityData.add(tempCity);

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
   return cityData;
    }
    
    
    
    public void SearchCity()
    {
        session=HibernateUtil.getSessionFactory().openSession();
        Scanner sc=new Scanner(System.in);
        String input=sc.next();
        Query q1=session.createSQLQuery("SELECT * FROM geolocation WHERE city='"+input+"'").addEntity(City.class);
       l1=q1.getResultList();
        System.out.println("city name: "+input+"  longitude: "+ l1.get(0).getLongitude()+" longitude: "+ l1.get(0).getLatitude()+"_");
    }
    public void printcity()
    {
        
    System.out.println(l1);
    }
}
