/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrix.multiply;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author aamnasayyed
 */
public class MATRIXMULTIPLY {

     public static int[][] multiplymatrix(int[][] a, int[][] b)
    {
       int A_rows=a.length;
       int B_rows=a[0].length;
       int B_cols=b[0].length;
       
       int [][] c=new int[A_rows][B_cols];
       
       for(int i=0;i<A_rows;i++)
       {
           
           for(int j=0;j<B_cols;j++)
           {
               int sum=0;
               for(int k=0;k<B_rows;k++)
               {
                   
                    sum= sum+a[i][k]*b[k][j];
               }
              c[i][j]=sum;
           }
       }
        return c;
    }

  public static int[][]strassenmultiply(int[][] a, int [][] b)
  {
      int n = a.length;
		int[][] C = new int [n][n];
		
		if(n == 1)
			C[0][0] = a[0][0] * b[0][0];
		
		else
		{
		
		int  P = ((a[0][0] + a[1][1])*(b[0][0]+ b[1][1]));
		int  q = ((a[1][0] + a[1][1])*b[0][0]);
		int  r = (a[0][0]*(b[0][1]-b[1][1]));
		int  s = (a[1][1]*(b[1][0]-b[0][0]));
		int  t = ((a[0][0]+a[1][1])*b[1][1]);
		int  u = ((a[1][0]-a[0][0])*(b[0][0]+ b[1][1]));
		int  v = ((a[0][1]- a[1][1])*(b[1][0]+b[1][1]));
		
		 C[0][0] = P + s - t + v;
		 C[0][1] = r + t;
		 C[1][0] = q + s;
		 C[1][1] = P - q + r + u;
		
		}
		
		return C;

      
      
  }
}
