/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrix.multiply;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aamnasayyed
 */
public class MATRIXMULTIPLYTest {
    
    public MATRIXMULTIPLYTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testMultiplymatrix() {
        System.out.println("multiplymatrix");
        int[][] a ={{1,2},{3,4}};
        int[][] b ={{1,2},{3,4}};
        int[][] expResult ={{7,10},{15,22}};
 
        int[][] result = MATRIXMULTIPLY.multiplymatrix(a, b);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    @Test
    public void testStrassenmultiply() {
        System.out.println("strassenmultiply");
        int[][] a ={{1,2},{3,4}};
        int[][] b ={{1,2},{3,4}};
        int[][] expResult={{7,10},{15,22}};
        int[][] result = MATRIXMULTIPLY.strassenmultiply(a, b);
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
